from builtins import range
from builtins import object
import numpy as np

from fcnet_classification_utils.layers import *
from fcnet_classification_utils.layers import softmax_loss

class FullyConnectedNet(object):
    """
    A fully-connected neural network with an arbitrary number of hidden layers,
    ReLU nonlinearities, and a softmax loss function. This will also implement
    dropout and batch normalization as options. For a network with L layers,
    the architecture will be

    {affine - [batch norm] - relu - [dropout]} x (L - 1) - affine - softmax

    where batch normalization and dropout are optional, and the {...} block is
    repeated L - 1 times.

    Similar to the TwoLayerNet above, learnable parameters are stored in the
    self.params dictionary and will be learned using the Solver class.
    """

    def __init__(self, hidden_dims, input_dim=3*32*32, num_classes=10,
                 dropout=0, use_batchnorm=False, reg=0.0,
                 weight_scale=1e-2, dtype=np.float32, seed=None):
        """
        Initialize a new FullyConnectedNet.

        Inputs:
        - hidden_dims: A list of integers giving the size of each hidden layer.
        - input_dim: An integer giving the size of the input.
        - num_classes: An integer giving the number of classes to classify.
        - dropout: Scalar between 0 and 1 giving dropout strength. If dropout=0 then
          the network should not use dropout at all.
        - use_batchnorm: Whether or not the network should use batch normalization.
        - reg: Scalar giving L2 regularization strength.
        - weight_scale: Scalar giving the standard deviation for random
          initialization of the weights.
        - dtype: A numpy datatype object; all computations will be performed using
          this datatype. float32 is faster but less accurate, so you should use
          float64 for numeric gradient checking.
        - seed: If not None, then pass this random seed to the dropout layers. This
          will make the dropout layers deteriminstic so we can gradient check the
          model.
        """
        self.use_batchnorm = use_batchnorm
        self.use_dropout = dropout > 0
        self.reg = reg
        self.num_layers = 1 + len(hidden_dims)
        self.dtype = dtype
        self.params = {}

        dims = [input_dim] + hidden_dims + [num_classes] #all the dimensions of network

        for i in range(self.num_layers): #for each layer
            self.params["W" + str(i+1)] = np.random.normal(scale = weight_scale, size = (dims[i], dims[i+1]))
            self.params["b" + str(i+1)] = np.zeros(dims[i+1])

            if (i != (self.num_layers - 1) and self.use_batchnorm):
                self.params["gamma" + str(i+1)] = np.ones(dims[i+1])
                self.params["beta" + str(i+1)] = np.zeros(dims[i+1])

        # When using dropout we need to pass a dropout_param dictionary to each
        # dropout layer so that the layer knows the dropout probability and the mode
        # (train / test). You can pass the same dropout_param to each dropout layer.
        self.dropout_param = {}
        if self.use_dropout:
            self.dropout_param = {'mode': 'train', 'p': dropout}
            if seed is not None:
                self.dropout_param['seed'] = seed

        # With batch normalization we need to keep track of running means and
        # variances, so we need to pass a special bn_param object to each batch
        # normalization layer. You should pass self.bn_params[0] to the forward pass
        # of the first batch normalization layer, self.bn_params[1] to the forward
        # pass of the second batch normalization layer, etc.
        self.bn_params = []
        if self.use_batchnorm:
            self.bn_params = [{'mode': 'train'} for i in range(self.num_layers - 1)]

        # Cast all parameters to the correct datatype
        for k, v in self.params.items():
            self.params[k] = v.astype(dtype)


    def loss(self, X, y=None):
        """
        Compute loss and gradient for the fully-connected net.

        Input / output: Same as TwoLayerNet above.
        """
        X = X.astype(self.dtype)
        mode = 'test' if y is None else 'train'

        # Set train/test mode for batchnorm params and dropout param since they
        # behave differently during training and testing.
        if self.use_dropout:
            self.dropout_param['mode'] = mode
        if self.use_batchnorm:
            for bn_param in self.bn_params:
                bn_param['mode'] = mode

        scores = None
        layer_input = X
        caches = [] #for backprop
        rl_caches = []
        if (self.use_dropout):
            dp_caches = []
        if (self.use_batchnorm):
            bn_caches = []
        for i in range(self.num_layers - 1): #last layer is just affine_forward
            layer_input, cache = affine_forward(layer_input, self.params["W" + str(i+1)], self.params["b" + str(i+1)])
            caches.append(cache)
            if (self.use_batchnorm):
                layer_input, cache = batchnorm_forward(layer_input, self.params["gamma" + str(i+1)], self.params["beta" + str(i+1)], self.bn_params[i] )
                bn_caches.append(cache)
            layer_input, cache = relu_forward(layer_input)
            rl_caches.append(cache)
            if (self.use_dropout):
                layer_input, d_cache = dropout_forward(layer_input, self.dropout_param)
                dp_caches.append(d_cache)
        scores, cache = affine_forward(layer_input, self.params["W" + str(self.num_layers)], self.params["b" + str(self.num_layers)])
        caches.append(cache)

        # If test mode return early
        if mode == 'test':
            return scores

        loss, grads = 0.0, {}
        #for the last layer
        loss, dloss = softmax_loss(scores, y)
        dloss, grads["W" + str(self.num_layers)], grads["b" + str(self.num_layers)] = affine_backward(dloss,caches[-1])
        loss += 0.5 * self.reg * np.sum(self.params["W" + str(self.num_layers)] * self.params["W" + str(self.num_layers)])
        grads["W" + str(self.num_layers)] += self.reg * self.params["W" + str(self.num_layers)]

        for i in range(self.num_layers-1, 0, -1): #from backward in the list and with which layer
            #dropout backward
            if (self.use_dropout):
                dloss = dropout_backward(dloss, dp_caches[i-1])
            #relu backward
            dloss = relu_backward(dloss, rl_caches[i-1])
            #batchnorm backward
            if (self.use_batchnorm):
                dloss, grads["gamma" + str(i)], grads["beta" + str(i)] = batchnorm_backward(dloss, bn_caches[i-1])
            #finally affine backward
            dloss, grads["W" + str(i)], grads["b" + str(i)] = affine_backward(dloss, caches[i-1])
            loss += 0.5 * self.reg * np.sum(self.params["W" + str(i)] * self.params["W" + str(i)])
            grads["W" + str(i)] += self.reg * self.params["W" + str(i)]

        return loss, grads
